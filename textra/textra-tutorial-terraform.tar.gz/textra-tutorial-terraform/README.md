# Textra Tutorials Template 

Textra教程模板工程，简化教程文档编写操作，使用MD,MDX快速开启在线教程的编写，可用于为技术学习、分享、考试的多用途，欢迎使用~

## Quick Start

### Overview

#### 教程效果图
![](public/textra-demo2.png)

#### 考场效果图
![](public/textra-demo3.png)


## Local Development

### 本地虚拟机ubuntu安装docker

虚拟机配置：
- CPU: 2C
- MEM: 4G
- Storage: 50G
- Network: NAT x 1, HostOnly x 1


```bash
cp /etc/apt/sources.list /etc/apt/sources.list.bak

cat >>/etc/apt/sources.list << EOF
deb https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ jammy main restricted
deb https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ jammy-updates main restricted
deb https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ jammy universe
deb https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ jammy-updates universe
deb https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ jammy multiverse
deb https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ jammy-updates multiverse
deb https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ jammy-backports main restricted universe multiverse
deb https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ jammy-security main restricted
deb https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ jammy-security universe
deb https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ jammy-security multiverse
EOF
```

安装docker
```bash
apt update
apt install docker.io
```
### VS Code server setup

code-server-st是一个Web版VS Code容器镜像, 预安装了Textra教程的所有依赖，如docker, git, nodejs, kubectl等，让你更专注的写教程。

环境要求，ubunut 20.04, docker

#### 使用本地虚拟机配置内部镜像仓库

```bash
vi /etc/docker/daemon.json
{
  "insecure-registries": [
    "109.131.8.236:5000"
  ]
}
```

#### 重启Docker

```bash
systemctl restart docker
```

#### 启动镜像

```bash
# 创建工作目录
$ mkdir -p /root/workspaces/myworkspace

# start docker
$ docker run -d --name code-server-st \
 --entrypoint /bin/sh \
 -v /root/workspaces/myworkspace:/workspace \
 -v /var/run/docker.sock:/var/run/docker.sock \
 -p 8080:8080 -p 3000:3000 -p 8899:8899 \
 109.131.8.236:5000/code-server-st:latest \
 -c "code-server --bind-addr 0.0.0.0:8080 --auth none"

```

 本地开发环境需要用到三个端口：

- 8080： Code server使用
- 3000： Textra Web端口
- 8899： gossh 端口

使用浏览器打开虚拟机的ip:8080端口

```bash
#或使用VitualBox的本地端口转发（教程略）
http://localhost:8080/

#也可以使用SSH转发（推荐）
ssh -f -NL 0.0.0.0:8080:127.0.0.1:8080 虚拟机ip
http://127.0.0.1:8080/

```

### Code Server效果图
![](public/textra-demo4.png)

### Workspace Setup
打开Terminal, Ctrl + ~, Clone代码仓库


打开工作目录(Web版VS中操作)

File -> Open Folder -> /workspace/textra-tutorial-template

安装指定版本node，pnpm

```bash
$ nvm use 18

$ node -v
v18.20.2


$ npm config set registry https://registry.npmmirror.com/

$ npm install -g pnpm

$ pnpm -v
9.0.6

```

初始化项目
```
cd /workspace/textra-tutorial-template
```

安装依赖
```bash
pnpm i
```

启动项目
```bash
pnpm dev
```

配置转发（可选）
```
# 如果使用ssh转发，还需要在办公电脑上开启别外两个端口转发
ssh -f -NL 0.0.0.0:3000:127.0.0.1:3000 虚拟机ip
ssh -f -NL 0.0.0.0:8899:127.0.0.1:8899 虚拟机ip
```

```
dependencies:
+ @vercel/og 0.5.0
+ clsx 2.0.0
+ framer-motion 10.0.0
+ next 13.5.6
+ nextra 2.13.4 <- ../packages/nextra
+ nextra-theme-docs 2.13.4 <- ../packages/nextra-theme-docs
+ react 18.2.0
+ react-dom 18.2.0
+ sharp 0.32.6

devDependencies:
+ @svgr/webpack 8.0.1
+ @types/node 18.20.2
+ @types/react 18.2.21
+ autoprefixer 10.4.15
+ eslint 8.35.0
+ postcss 8.4.31
+ tailwindcss 3.3.3
```

## 如何写文档

环境搭建好后，你只需要编写或创建pages下面的.md或.mdx文件或目录， Textra会自动生成相应的网页，文件被编辑后，会自动编译和刷新页面。

_meta.json文件可以用来管理文件的排序和显示名称，没有的话，Textra会按字母顺序进行排序，推荐使用。

MDX语法手册已集成在项目中，可以直接打开查看。

注意： 首次访问新页面会有较长的编译时间，需要稍微等待即可。

参考目录结构
```
pages/
├── about.mdx
├── exam
│   ├── _meta.json
│   ├── page1.mdx
│   ├── page2.mdx
│   └── page3.mdx
├── index.mdx
├── _meta.json
└── tutorial
    ├── chapter1
    │   ├── page1.mdx
    │   └── page2.mdx
    ├── chapter2
    │   ├── page1.mdx
    │   └── page2.mdx
    ├── index.mdx
    ├── page1.mdx
    └── page2.mdx
```

## Delpoy

### Docker build

Build your container: 
```
sudo docker build -t textra-tutorial-template .
```

Run your container: 
```
sudo docker run -p 3000:3000 textra-tutorial-template
```

### Locally Docker build

```bash
pnpm build

sudo docker build -t textra-tutorial-template -f local.Dockerfile .
```



## How to use


### 在本地虚拟机启动教程镜像

```bash
 docker run -d --name textra-tutorial-template -p 3000:3000 -p 8899:8899 109.131.8.236:5000/textra-tutorial-template
```

从docker中copy相关工具

```bash
docker cp k8s-playgroud:/usr/bin/k3d   /usr/bin/
docker cp k8s-playgroud:/usr/bin/kubectl   /usr/bin/
docker cp k8s-playgroud:/usr/bin/helm   /usr/bin/
docker cp k8s-playgroud:/usr/bin/docker-compose   /usr/bin/
```
创建ssh连接，使用 “保存并连接”，这样后继可以直接打开ssh连接。

