import React from 'react'
import { DocsThemeConfig } from 'nextra-theme-docs'

const config: DocsThemeConfig = {
  logo: <span>Tutorial</span>,
  project: {
    link: '#',
  },
  chat: {
    link: 'https://discord.com',
  },
  docsRepositoryBase: '#',
  footer: {
    text: 'Terraform tutorial',
  },
}

export default config
