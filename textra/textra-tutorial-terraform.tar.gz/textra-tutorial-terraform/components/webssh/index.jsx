// Example from https://beta.reactjs.org/learn

import React, { useEffect, useRef } from 'react';
import $ from "jquery"

export default function WebSSH() {
    

    useEffect(() => {

        let heightOfWebSHH = 300
        const webshellurl = "http://" + window.location.hostname + ":8899"

        $("body").css("padding-bottom", heightOfWebSHH)
        $("footer")
            .css("height", heightOfWebSHH)
            .css("position", "fixed")
            .css("width", "100%")
            .css("z-index", "999")
            .css("bottom", 0)

        const buttons = '<div style="width:50px"><a id="close" herf="#">Close</a></div><div><a id="increase" herf="#">+</a></div><div><a id="decrease" herf="#">-</a></div>'
        $("footer").html("<div id='webssh' class='nx-mx-auto nx-flex nx-max-w-[90rem] nx-gap-2 nx-py-2 nx-px-4'>" + buttons + "<iframe id='ssh-window' width='100%' height='" + (heightOfWebSHH - 10) + "' src='" + webshellurl + "' frameborder='0' allowfullscreen=''></iframe><div>")
        $("#close").click(function () {
            if ($(this).text() == "Close") {
                $("footer").css("height", 30)
                $(this).text("Open")
            } else {
                $("footer").css("height", heightOfWebSHH)
                $(this).text("Close")
            }
        })
        $("#increase").click(function () {
            if (heightOfWebSHH < 1000) {
                heightOfWebSHH += 100
            }
            resizeSSHWindow()
        })
        $("#decrease").click(function () {
            if (heightOfWebSHH > 200) {
                heightOfWebSHH -= 100
            }
            resizeSSHWindow()
        })

        function resizeSSHWindow() {
            $("body").css("padding-bottom", heightOfWebSHH)
            $("footer").css("height", heightOfWebSHH)
            $("#ssh-window").css("height", heightOfWebSHH - 10)
        }
    }, [])

    return (
        <></>
    )
}
